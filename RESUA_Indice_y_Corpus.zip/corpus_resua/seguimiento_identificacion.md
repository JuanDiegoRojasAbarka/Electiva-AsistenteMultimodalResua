# Guía de seguimiento e identificación

## Consulta del estado

El estado de un avistamiento registrado se consulta mediante su código de seguimiento, por ejemplo AVS-1001. La consulta permite conocer el estado actual del registro y la información disponible sobre su proceso de revisión.

Conserve el código asignado al avistamiento para realizar consultas posteriores. El código debe corresponder al registro que se desea consultar.

## Identificación de especies

Cuando un avistamiento contiene fotografías, descripciones u otras evidencias, esta información puede utilizarse como apoyo para identificar la especie observada.

Si la evidencia disponible no permite determinar la especie con suficiente confianza, el registro puede permanecer pendiente de identificación. La identificación no debe inventarse cuando las evidencias son insuficientes.

## Revisión humana

Los casos que requieran intervención de una autoridad ambiental, atención especializada o revisión de información sensible deben ser remitidos para revisión humana.
