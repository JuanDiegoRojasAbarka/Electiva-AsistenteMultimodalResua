# Guía de registro de avistamientos

## Registrar un avistamiento

Para registrar un avistamiento en RESUA, indique la ubicación, fecha, hora y una descripción del animal observado. Si dispone de una fotografía, puede adjuntarla como evidencia para apoyar la identificación de la especie.

La descripción debe incluir, cuando sea posible, características visibles como tamaño aproximado, coloración, forma del cuerpo y comportamiento observado.

No se debe inventar información que no haya sido observada. Si algún dato no está disponible, el registro puede quedar pendiente de información.

## Evidencia fotográfica

Las fotografías pueden utilizarse como evidencia complementaria del avistamiento. Una imagen borrosa o con poca información visible puede no ser suficiente para identificar la especie.

La fotografía no reemplaza los datos básicos del avistamiento, como la ubicación y la fecha de observación.
